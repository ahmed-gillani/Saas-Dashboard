// src/api/usersApi.types.ts
import type { User } from '../types/auth.types'

export interface GetUsersParams {
  page?:   number
  limit?:  number
  search?: string
  role?:   'all' | 'admin' | 'user'
  status?: 'all' | 'active' | 'inactive'
}

export interface PaginatedUsers {
  users:      User[]
  total:      number
  page:       number
  totalPages: number
}

export interface CreateUserInput {
  name:     string
  email:    string
  password: string
  role:     'admin' | 'user'
}

export interface UpdateUserInput {
  name?:   string
  email?:  string
  role?:   'admin' | 'user'
  status?: 'active' | 'inactive'
}