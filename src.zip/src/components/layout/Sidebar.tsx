import { NavLink } from 'react-router-dom'
import {
  Home, LayoutDashboard, Users, BarChart2, Settings,
  ShieldCheck, LogOut
} from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { useLogout } from '../../hooks/useAuth'

const homeLink = { to: '/home', label: 'Home', icon: Home }

const adminLinks = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/users', label: 'Users', icon: Users },
  { to: '/analytics', label: 'Analytics', icon: BarChart2 },
]

const configLinks = [
  { to: '/settings', label: 'Settings', icon: Settings },
  { to: '/roles', label: 'Roles', icon: ShieldCheck },
]

export default function Sidebar() {
  const { user } = useAuthStore()
  const logout = useLogout()
  const isAdmin = user?.role === 'admin'

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 px-4 py-2.5 text-sm border-l-2 transition-all ${
      isActive
        ? 'text-violet-400 bg-violet-500/10 border-violet-500'
        : 'text-gray-500 border-transparent hover:text-gray-200 hover:bg-gray-800/50'
    }`

  return (
    <aside className="w-52 bg-gray-900 border-r border-gray-800 flex flex-col h-full shrink-0">
      {/* Logo */}
      <div className="px-4 py-5">
        <span className="text-violet-400 font-bold text-lg tracking-tight">
          nexus<span className="text-white font-light">.io</span>
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto">
        <p className="px-4 pt-2 pb-1 text-[10px] uppercase tracking-widest text-gray-600">Navigation</p>
        <NavLink to="/home" className={linkClass}>
          <Home size={15} className="shrink-0" /> Home
        </NavLink>

        {isAdmin && (
          <>
            <p className="px-4 pt-4 pb-1 text-[10px] uppercase tracking-widest text-gray-600">Admin</p>
            {[
              { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { to: '/users',     label: 'Users',     icon: Users },
              { to: '/analytics', label: 'Analytics', icon: BarChart2 },
            ].map(({ to, label, icon: Icon }) => (
              <NavLink key={to} to={to} className={linkClass}>
                <Icon size={15} className="shrink-0" /> {label}
              </NavLink>
            ))}
          </>
        )}

        <p className="px-4 pt-4 pb-1 text-[10px] uppercase tracking-widest text-gray-600">Config</p>
        {[
          { to: '/settings', label: 'Settings', icon: Settings },
          { to: '/roles',    label: 'Roles',    icon: ShieldCheck },
        ].map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to} className={linkClass}>
            <Icon size={15} className="shrink-0" /> {label}
          </NavLink>
        ))}
      </nav>

      {/* User section — logout always visible */}
      <div className="p-3 border-t border-gray-800 space-y-1">
        {/* User info */}
        <div className="flex items-center gap-2.5 px-2 py-2 rounded-lg bg-gray-800">
          <div className="w-7 h-7 rounded-full bg-violet-600 flex items-center justify-center text-white text-[10px] font-bold shrink-0">
            {user?.name?.slice(0, 2).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-gray-200 truncate">{user?.name}</p>
            <p className="text-[10px] text-gray-500 capitalize">{user?.role}</p>
          </div>
        </div>
        {/* Logout button — always visible */}
        <button
          onClick={logout}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors text-xs"
        >
          <LogOut size={14} />
          Sign Out
        </button>
      </div>
    </aside>
  )
}